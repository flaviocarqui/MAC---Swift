//
//  CountriesTableViewController.swift
//  Passport
//
//  Created by user126552 on 6/3/17.
//  Copyright © 2017 user126552. All rights reserved.
//

import UIKit


class CountriesTableViewController: UITableViewController {

    //	Declare the array
    var countries = ["Italy","Norway","England"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // The numberOfSectionsInTableView method specifies the number of sections to be shown in the table view. Instead of 0, put 1
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // This method specifies the number of rows to be shown in the table view. As we have 3 records in Array
        return countries.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        
        cell.textLabel?.text = countries[indexPath.row]
        
        return cell
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
}
