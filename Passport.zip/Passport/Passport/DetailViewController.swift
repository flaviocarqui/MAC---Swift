//
//  DetailViewController.swift
//  Passport


import UIKit
import MapKit

class DetailViewController: UIViewController, MKMapViewDelegate {
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var currentTime: UILabel!
    @IBOutlet weak var temprature: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var blackView: UIView!

    var selectedCountry:NSDictionary!
    var localTime:String!
    var finalTime:Int = 0
    var arrOfImages: NSArray!
    var maxIndex: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        
        self.setArrayOfImages()

        
        blackView.backgroundColor = UIColor(white: 0, alpha: 0.8)
        let lat = selectedCountry["lat"];
        let long = selectedCountry["long"];
        let gmt = selectedCountry["gmt"];
        
        let timeZone = (gmt as! NSString).intValue-5
        let latitude = (lat as! NSString).doubleValue
        let longitude = (long as! NSString).doubleValue
        
        let date = Date()
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        let seconds = calendar.component(.second, from: date)
        
        if(hour+timeZone > 23){
            finalTime = hour+timeZone-24
        }
        else{
            finalTime = Int(timeZone.toIntMax()) + hour
        }
        let hourStr = String(finalTime)
        let minuteStr = String(minutes)
        let secondString = String(seconds)
        
        
        currentTime.text = hourStr+":"+minuteStr+":"+secondString
        let temp = selectedCountry["temp"]
        temprature.text = temp as! String?
       let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        mapView.addAnnotation(annotation)
        mapView.showAnnotations(mapView.annotations, animated: true)
        
        let span = MKCoordinateSpanMake(latitude/2, longitude/2)
        let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: latitude, longitude: longitude), span: span)
        mapView.setRegion(region, animated: true)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizerDirection.right
        self.blackView.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeLeft.direction = UISwipeGestureRecognizerDirection.left
        self.blackView.addGestureRecognizer(swipeLeft)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
                // Dispose of any resources that can be recreated.
    }
    
    @IBAction func hideImageView(_ sender: UIButton) {
        imgView.isHidden = true
        blackView.isHidden = true
        maxIndex = 0;
    }
    
    @IBAction func viewGallery(_ sender: UIButton) {
        if (arrOfImages != nil) {
            imgView.isHidden = false
            blackView.isHidden = false
            imgView.image = UIImage(named: arrOfImages[maxIndex] as! String)
        }
    }
    
    func setArrayOfImages() -> Void {
         if selectedCountry["name"] as! String == "France" {
            arrOfImages = ["f1.jpg", "f2.jpg"];
            
        }
        else if selectedCountry["name"] as! String == "Germany" {
            arrOfImages = ["i1.jpg", "i2.jpg"];
            
        }
        else if selectedCountry["name"] as! String == "Poland" {
            arrOfImages = ["c1.jpg", "c2.jpg"];
            
        }
    }
    
    func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.right:
                if maxIndex > 0 {
                    maxIndex -= 1;
                    if maxIndex < 0 {
                        maxIndex = 0;
                    }
                    imgView.image = UIImage(named: arrOfImages[maxIndex] as! String)
                }
            case UISwipeGestureRecognizerDirection.down:
                print("Swiped down")
            case UISwipeGestureRecognizerDirection.left:
                if maxIndex < 4 {
                    maxIndex += 1;
                    if maxIndex > 3 {
                        maxIndex = 3
                    }
                    imgView.image = UIImage(named: arrOfImages[maxIndex] as! String)
                }
            case UISwipeGestureRecognizerDirection.up:
                print("Swiped up")
            default:
                break
            }
        }
    }

}
