	//
//  ViewController.swift
//  HelloSwift
//
//  Created by user126552 on 5/21/17.
//  Copyright © 2017 user126552. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var helloLabel: UILabel!
   
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var sayHelloButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        setupUI()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func setupUI() {
        helloLabel.text = "Hello Swift!"
        helloLabel.textColor = UIColor.red
        helloLabel.textAlignment = NSTextAlignment.center
        
        nameTextField.placeholder = "Enter your name"
        sayHelloButton.setTitle("Say Hello", for: [])
        
    }
    
    @IBAction func sayHelloAction(sender : AnyObject) {
        
        let name = nameTextField.text
        
        if (name!.isEmpty) {
            
            let alert = UIAlertController(title: "Error", message: "Please enter a name",preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,
                                          handler: nil))
            
            self.present(alert, animated: true, completion: nil)
        } else {
            
 helloLabel.text = "Hello \(name!)"
        }
    }
    
}

