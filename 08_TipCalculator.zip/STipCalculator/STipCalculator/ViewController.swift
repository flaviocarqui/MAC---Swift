//
//  ViewController.swift
//  STipCalculator
//
//  Created by Hamid on 5/14/16.
//  Copyright © 2016 HuxTek. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var billAmountField: UITextField!
    @IBOutlet weak var tipPercentageLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var tipAmountLabel: UILabel!
    @IBOutlet weak var tpSlider: UISlider!
    
    @IBAction func calculatePressed(sender: UIButton) {
        calculateTip()
    }
    
    @IBAction func sliderChanged(sender: UISlider) {
        tipPercentageLabel.text! = "Tip Percentage " + String(Int(sender.value)) + "%"
        calculateTip()
    }
    
    func calculateTip() {
        var tipAmount = Float()
        var total = Float()
        if let billAmount = Float(billAmountField.text!) {
            tipAmount = billAmount * tpSlider.value/100
            total = tipAmount + billAmount
        }
        else {
            tipAmount = 0
            total = 0
        }
        tipAmountLabel.text! = String(tipAmount)
        totalLabel.text! = String(total)
    }
}

