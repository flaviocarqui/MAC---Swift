//
//  RaceCar.swift
//  RaceCar
//
//  Created by user126552 on 6/2/17.
//  Copyright © 2017 user126552. All rights reserved.
//

import UIKit

class RaceCar: NSObject{
    var brand: String = "Ferrari"
    var color: String = "Red"
    var topSpeed: Int = 200
    func honk(){
        print("Honk! Honk!")
    }
}
